// AddDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ImageTool.h"
#include "AddDlg.h"
#include <SHLWAPI.H>
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddDlg dialog


CAddDlg::CAddDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAddDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddDlg)
	m_sPathName = _T("");
	m_sPicName = _T("");
	m_sA = _T("������A��");
	m_sB = _T("������B��");
	m_sC = _T("������C��");
	m_sD = _T("������D��");
	m_nAnswer = -1;
	//}}AFX_DATA_INIT
}


void CAddDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddDlg)
	DDX_Control(pDX, IDC_IMAGE_GRADE, m_cmbo_ImageGrade);
	DDX_Text(pDX, IDC_EDIT_PATH, m_sPathName);
	DDX_Text(pDX, IDC_PIC_NAME, m_sPicName);
	DDX_Text(pDX, IDC_EDITA, m_sA);
	DDX_Text(pDX, IDC_EDITB, m_sB);
	DDX_Text(pDX, IDC_EDITC, m_sC);
	DDX_Text(pDX, IDC_EDITD, m_sD);
	DDX_Radio(pDX, IDC_RADIOA, m_nAnswer);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddDlg, CDialog)
	//{{AFX_MSG_MAP(CAddDlg)
	ON_BN_CLICKED(IDC_BTN_ADD, OnBtnAdd)
	ON_BN_CLICKED(IDC_BTN_INSERT, OnBtnInsert)
	ON_WM_CREATE()
	ON_BN_CLICKED(IDC_RADIOA, OnRadioa)
	ON_BN_CLICKED(IDC_RADIOB, OnRadiob)
	ON_BN_CLICKED(IDC_RADIOC, OnRadioc)
	ON_BN_CLICKED(IDC_RADIOD, OnRadiod)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddDlg message handlers

void CAddDlg::OnBtnAdd() 
{
	UpdateData(TRUE);
	// TODO: Add your control notification handler code here
	if (m_sPicName.IsEmpty() || m_sPathName.IsEmpty()  ||m_cmbo_ImageGrade.GetCurSel() == -1){
		AfxMessageBox(_T("��������Ƿ����Ҫ��"));
		return ;
	}

	if (m_nAnswer == -1)
	{
		AfxMessageBox("��ѡ����ȷ��");
		return ;
	}


	int nCurPos = m_cmbo_ImageGrade.GetCurSel();
	CString sPath;
	GetSoundPath(nCurPos+1,sPath);
	m_nIndex = nCurPos +1;
	
	sPath += "\\" + m_sPicName;

	CopyFile(m_sPathName,sPath,FALSE);

	m_SoundInfo.sA = m_sA;
	m_SoundInfo.sB = m_sB;
	m_SoundInfo.sC = m_sC;
	m_SoundInfo.sD = m_sD;
	m_SoundInfo.grade = (Sound_Grade)(nCurPos + 1);
	GetAnswer(m_nAnswer,m_SoundInfo.sAnswer);
	m_SoundInfo.sSoundName = m_sPicName;
	m_SoundInfo.sSoundPath = sPath;

	OnOK();

	
}

void CAddDlg::OnBtnInsert() 
{
	// TODO: Add your control notification handler code here
	char   cFileName[256] = {0}; 
     GetCurrentDirectory(256,cFileName);
	CFileDialog FileDlg( TRUE , _T("(*.mp3)|*.mp3"),_T("*.mp3") ,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT ,_T("mp3��Ƶ(*.mp3)"));
	
	if(FileDlg.DoModal()==IDOK) 
		
	{ 
		m_sPathName = FileDlg.GetPathName();
		m_sPicName = FileDlg.GetFileName();
	}
	else{
		SetCurrentDirectory(cFileName);
		return ;
	}
	SetCurrentDirectory(cFileName);
	UpdateData(FALSE);
	
}

int CAddDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here

	
	return 0;
}

BOOL CAddDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_cmbo_ImageGrade.AddString("һ���");
	m_cmbo_ImageGrade.AddString("һ����ͨ");
	m_cmbo_ImageGrade.AddString("һ������");
	m_cmbo_ImageGrade.AddString("�����");
	m_cmbo_ImageGrade.AddString("������ͨ");
	m_cmbo_ImageGrade.AddString("��������");
	m_cmbo_ImageGrade.AddString("�����");
	m_cmbo_ImageGrade.AddString("������ͨ");
	m_cmbo_ImageGrade.AddString("��������");
	m_cmbo_ImageGrade.AddString("�����");
	m_cmbo_ImageGrade.AddString("������ͨ");
	m_cmbo_ImageGrade.AddString("��������");


	return TRUE;
}
void CAddDlg::GetSoundPath( int index,CString &sPath )
{
	switch(index)
	{
	case 1:
		sPath = ".\\config\\mp3\\1\\easy";
		break;
	case 2:
		sPath = ".\\config\\mp3\\1\\middle";
		break;
	case 3:
		sPath = ".\\config\\mp3\\1\\hard";
		break;
	case 4:
		sPath = ".\\config\\mp3\\2\\easy";
		break;
	case 5:
		sPath = ".\\config\\mp3\\2\\middle";
		break;
	case 6:
		sPath = ".\\config\\mp3\\2\\hard";
		break;
	case 7:
		sPath = ".\\config\\mp3\\3\\easy";
		break;
	case 8:
		sPath = ".\\config\\mp3\\3\\middle";
		break;
	case 9:
		sPath = ".\\config\\mp3\\3\\hard";
		break;
	case 10:
		sPath = ".\\config\\mp3\\4\\easy";
		break;
	case 11:
		sPath = ".\\config\\mp3\\4\\middle";
		break;
	case 12:
		sPath = ".\\config\\mp3\\4\\hard";
		break;
	default:
		break;
	}
	
}

void CAddDlg::GetAnswer( int index,CString &sAnswer )
{
	switch(index)
	{
	case 0:
		sAnswer = "A";
		break;
	case 1:
		sAnswer = "B";
		break;
	case 2:
		sAnswer = "C";
		break;
	case 3:
		sAnswer = "D";
		break;
	default:
		break;
	}
}

void CAddDlg::OnRadioa() 
{
	// TODO: Add your control notification handler code here
	m_nAnswer=0;
}

void CAddDlg::OnRadiob() 
{
	// TODO: Add your control notification handler code here
	m_nAnswer=1;
	
}

void CAddDlg::OnRadioc() 
{
	// TODO: Add your control notification handler code here
	m_nAnswer=2;
	
}

void CAddDlg::OnRadiod() 
{
	// TODO: Add your control notification handler code here
	m_nAnswer=3;
}
