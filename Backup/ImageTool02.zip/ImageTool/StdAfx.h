// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__F82F9325_1796_40D2_958C_6548A6B04C81__INCLUDED_)
#define AFX_STDAFX_H__F82F9325_1796_40D2_958C_6548A6B04C81__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <comdef.h>//��ʼ��һ��com��
// #ifndef ULONG_PTR
// #define   ULONG_PTR   void*
// // #include "GdiPlus.h"
// // using namespace Gdiplus;
//  #endif
// // #pragma comment(lib,"gdiplus.lib")


#include <iostream>
using namespace std;
#include <string>
#include <list>
#include <map>
#include "Markup.h"

enum Image_Grade
{
	GradeUnknown = -1,
		GradeA ,
		GradeB,
		GradeC,
		GradeD,
};

typedef struct tag_Image
{
	Image_Grade grade;
	CString sImagePath;
	CString sImageName;
}IMAGE_INFO;


enum Sound_Grade
{
	GradeUnknown2 = -1,
		GradeA_Easy =1,
		GradeA_Normal,
		GradeA_Hard,
		GradeB_Easy ,
		GradeB_Normal,
		GradeB_Hard,
		GradeC_Easy ,
		GradeC_Normal,
		GradeC_Hard,
		GradeD_Easy ,
		GradeD_Normal,
		GradeD_Hard,

};

typedef struct tag_Sound
{
	Sound_Grade grade;
	CString sSoundPath;
	CString sSoundName;
	CString sA;
	CString sB;
	CString sC;
	CString sD;
	CString sAnswer;
}SOUND_INFO;
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__F82F9325_1796_40D2_958C_6548A6B04C81__INCLUDED_)
