//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ImageTool.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_IMAGETOOL_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_ADD_DIALOG                  129
#define IDD_MODIFY_DIALOG               131
#define IDD_DIALOG1                     132
#define IDC_PNG                         1000
#define IDC_BUTTON1                     1001
#define IDC_LIST_IMAGE                  1003
#define IDC_BTN_ADD                     1004
#define IDC_EDIT_PATH                   1005
#define IDC_BTN_MODIFY                  1005
#define IDC_EDIT_NAME                   1006
#define IDC_BTN_DELETE                  1006
#define IDC_IMAGE_GRADE                 1007
#define IDC_PIC_NAME                    1008
#define IDC_BTN_INSERT                  1009
#define IDC_COMBO_GRADE                 1011
#define IDC_EDIT_PATH_SOURCE            1012
#define IDC_BTN_SAVE                    1013
#define IDC_RADIOA                      1014
#define IDC_RADIOB                      1015
#define IDC_RADIOC                      1016
#define IDC_RADIOD                      1017
#define IDC_EDITA                       1018
#define IDC_EDITB                       1019
#define IDC_EDITC                       1020
#define IDC_EDITD                       1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
