#if !defined(AFX_MODIFYDLG_H__DB45EC46_BC8C_493F_9BF8_33F907D5083E__INCLUDED_)
#define AFX_MODIFYDLG_H__DB45EC46_BC8C_493F_9BF8_33F907D5083E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ModifyDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CModifyDlg dialog

class CModifyDlg : public CDialog
{
// Construction
public:
	CModifyDlg(SOUND_INFO *pSoundInfo,CWnd* pParent = NULL);   // standard constructor

	IMAGE_INFO * m_pImage;
	SOUND_INFO  * m_pSoundInfo;

	int GetCurIndex(CString & sAnswer);
	void GetSoundPath( int index,CString &sPath );
// Dialog Data
	//{{AFX_DATA(CModifyDlg)
	enum { IDD = IDD_MODIFY_DIALOG };
	CComboBox	m_cmbo_ImageGrade;
	CString	m_sSoundName;
	CString	m_sSoundPath;
	int		m_nIndex;
	CString	m_sA;
	CString	m_sB;
	CString	m_sC;
	CString	m_sD;
	CString	m_sThSoundName;
	CString	m_sPathSource;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CModifyDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

		virtual BOOL OnInitDialog();


	// Generated message map functions
	//{{AFX_MSG(CModifyDlg)
	afx_msg void OnBtnInsert();
	afx_msg void OnBtnSave();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MODIFYDLG_H__DB45EC46_BC8C_493F_9BF8_33F907D5083E__INCLUDED_)
