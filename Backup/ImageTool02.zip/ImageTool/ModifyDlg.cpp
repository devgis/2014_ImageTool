// ModifyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ImageTool.h"
#include "ModifyDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CModifyDlg dialog


CModifyDlg::CModifyDlg(SOUND_INFO *pSoundInfo,CWnd* pParent /*=NULL*/)
	: CDialog(CModifyDlg::IDD, pParent)
{
	m_pSoundInfo = pSoundInfo;
	//{{AFX_DATA_INIT(CModifyDlg)
	m_sSoundName = _T("");
	m_sSoundPath = _T("");
	m_nIndex = -1;
	m_sA = _T("");
	m_sB = _T("");
	m_sC = _T("");
	m_sD = _T("");
	m_sThSoundName = _T("");
	m_sPathSource = _T("");
	//}}AFX_DATA_INIT
}


void CModifyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CModifyDlg)
	DDX_Control(pDX, IDC_COMBO_GRADE, m_cmbo_ImageGrade);
	DDX_Text(pDX, IDC_EDIT_NAME, m_sSoundName);
	DDX_Text(pDX, IDC_EDIT_PATH, m_sSoundPath);
	DDX_Radio(pDX, IDC_RADIOA, m_nIndex);
	DDX_Text(pDX, IDC_EDITA, m_sA);
	DDX_Text(pDX, IDC_EDITB, m_sB);
	DDX_Text(pDX, IDC_EDITC, m_sC);
	DDX_Text(pDX, IDC_EDITD, m_sD);
	DDX_Text(pDX, IDC_PIC_NAME, m_sThSoundName);
	DDX_Text(pDX, IDC_EDIT_PATH_SOURCE, m_sPathSource);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CModifyDlg, CDialog)
	//{{AFX_MSG_MAP(CModifyDlg)
	ON_BN_CLICKED(IDC_BTN_INSERT, OnBtnInsert)
	ON_BN_CLICKED(IDC_BTN_SAVE, OnBtnSave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CModifyDlg::OnInitDialog()
{
	CDialog::OnInitDialog();


	m_cmbo_ImageGrade.AddString("һ���");
	m_cmbo_ImageGrade.AddString("һ����ͨ");
	m_cmbo_ImageGrade.AddString("һ������");
	m_cmbo_ImageGrade.AddString("�����");
	m_cmbo_ImageGrade.AddString("������ͨ");
	m_cmbo_ImageGrade.AddString("��������");
	m_cmbo_ImageGrade.AddString("�����");
	m_cmbo_ImageGrade.AddString("������ͨ");
	m_cmbo_ImageGrade.AddString("��������");
	m_cmbo_ImageGrade.AddString("�����");
	m_cmbo_ImageGrade.AddString("������ͨ");
	m_cmbo_ImageGrade.AddString("��������");

	m_sSoundName = m_pSoundInfo->sSoundName;
	m_sSoundPath = m_pSoundInfo->sSoundPath;
	m_cmbo_ImageGrade.SetCurSel((int)m_pSoundInfo->grade -1);
	m_nIndex = GetCurIndex(m_pSoundInfo->sAnswer);

	m_sA = m_pSoundInfo->sA;
	m_sB = m_pSoundInfo->sB;
	m_sC = m_pSoundInfo->sC;
	m_sD = m_pSoundInfo->sD;
	

	UpdateData(FALSE);


	
	
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CModifyDlg message handlers

void CModifyDlg::OnBtnInsert() 
{
	// TODO: Add your control notification handler code here
	char   cFileName[256] = {0}; 
     GetCurrentDirectory(256,cFileName);

	CFileDialog FileDlg( TRUE , _T("(*.mp3)|*.mp3"),_T("*.mp3") ,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT ,_T("mp3��Ƶ(*.mp3)"));
	
	if(FileDlg.DoModal()==IDOK) 
		
	{ 
		m_sPathSource = FileDlg.GetPathName();
		m_sThSoundName = FileDlg.GetFileName();
	}
	else{
		SetCurrentDirectory(cFileName);
		return ;
	}
	SetCurrentDirectory(cFileName);
	UpdateData(FALSE);
	
}

void CModifyDlg::GetSoundPath( int index,CString &sPath )
{
	switch(index)
	{
	case 1:
		sPath = ".\\config\\mp3\\1\\easy";
		break;
	case 2:
		sPath = ".\\config\\mp3\\1\\middle";
		break;
	case 3:
		sPath = ".\\config\\mp3\\1\\hard";
		break;
	case 4:
		sPath = ".\\config\\mp3\\2\\easy";
		break;
	case 5:
		sPath = ".\\config\\mp3\\2\\middle";
		break;
	case 6:
		sPath = ".\\config\\mp3\\2\\hard";
		break;
	case 7:
		sPath = ".\\config\\mp3\\3\\easy";
		break;
	case 8:
		sPath = ".\\config\\mp3\\3\\middle";
		break;
	case 9:
		sPath = ".\\config\\mp3\\3\\hard";
		break;
	case 10:
		sPath = ".\\config\\mp3\\4\\easy";
		break;
	case 11:
		sPath = ".\\config\\mp3\\4\\middle";
		break;
	case 12:
		sPath = ".\\config\\mp3\\4\\hard";
		break;
	default:
		break;
	}
	
}

void GetAnswer( int index,CString &sAnswer )
{
	switch(index)
	{
	case 0:
		sAnswer = "A";
		break;
	case 1:
		sAnswer = "B";
		break;
	case 2:
		sAnswer = "C";
		break;
	case 3:
		sAnswer = "D";
		break;
	default:
		break;
	}
}
void CModifyDlg::OnBtnSave() 
{
	// TODO: Add your control notification handler code here

	UpdateData(TRUE);
	if (m_sSoundName.IsEmpty() /*|| m_sPicName.IsEmpty()*/){
		AfxMessageBox(_T("��������Ƿ����Ҫ��"));
		return ;
	}

	//�滻��Ƶ
	CString sPath;
	CString sName;
	if (!m_sPathSource.IsEmpty())
	{
		DeleteFile(m_sSoundPath);
		GetSoundPath(m_cmbo_ImageGrade.GetCurSel() + 1,sPath);
		sPath += "\\" + m_sThSoundName;
		CopyFile(m_sPathSource,sPath,FALSE);
		sName = m_sThSoundName;
	}
	else
	{
		GetSoundPath(m_cmbo_ImageGrade.GetCurSel() + 1,sPath);
		sPath += "\\" + m_sSoundName;
		if (m_sSoundPath == sPath)
		{
			int iii = 0;
		}
		else
		{
			CopyFile(m_sSoundPath,sPath,FALSE);
			DeleteFile(m_sPathSource);
		}
		sName = m_sSoundName;
	}

	m_pSoundInfo->grade = (Sound_Grade)(m_cmbo_ImageGrade.GetCurSel()+1);
	m_pSoundInfo->sA = m_sA;
	m_pSoundInfo->sB = m_sB;
	m_pSoundInfo->sC = m_sC;
	m_pSoundInfo->sD = m_sD;
	GetAnswer(m_nIndex,m_pSoundInfo->sAnswer);
	m_pSoundInfo->sSoundName = sName;
	m_pSoundInfo->sSoundPath = sPath;
	
	OnOK();

	
}

int CModifyDlg::GetCurIndex( CString & sAnswer )
{
	if (sAnswer == "A")
	{
		return 0;
	}
	else if (sAnswer == "B")
	{
		return 1;
	}
	else if (sAnswer == "C")
	{
		return 2;
	}
	else if (sAnswer == "D")
	{
		return 3;
	}
	return -1;
}
