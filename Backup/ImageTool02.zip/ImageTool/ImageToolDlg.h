// ImageToolDlg.h : header file
//

#if !defined(AFX_IMAGETOOLDLG_H__7DD2DF0F_DDA8_467F_987F_790E80B11999__INCLUDED_)
#define AFX_IMAGETOOLDLG_H__7DD2DF0F_DDA8_467F_987F_790E80B11999__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


/////////////////////////////////////////////////////////////////////////////
// CImageToolDlg dialog

typedef std::list<IMAGE_INFO*>  IMAGE_LIST;  

typedef std::list<SOUND_INFO*>  SOUND_LIST;  
typedef std::map<int,SOUND_LIST> SOUND_MAP;

class CImageToolDlg : public CDialog
{
// Construction
public:
	CImageToolDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CImageToolDlg)
	enum { IDD = IDD_IMAGETOOL_DIALOG };
	CListCtrl	m_ctrlImage;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImageToolDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	IMAGE_LIST  m_lstImage;
	SOUND_MAP   m_mapSound;


	BOOL LoadSound(SOUND_MAP &mapSound);
	void GetSoundPath(int index,CString &sPath);
	int GetSoundCount();



	//��ʾͼƬ
	void ShowPng(CString sName);
	//����ͼƬ
	BOOL LoadImage(IMAGE_LIST &imageList);
	//��ʼ��
	void Init();
	void InitCtrl();

	//����xml
	void SaveXml();


	// Generated message map functions
	//{{AFX_MSG(CImageToolDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnItemchangedListImage(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemchangingListImage(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnBtnAdd();
	afx_msg void OnBtnDelete();
	afx_msg void OnBtnModify();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMAGETOOLDLG_H__7DD2DF0F_DDA8_467F_987F_790E80B11999__INCLUDED_)
