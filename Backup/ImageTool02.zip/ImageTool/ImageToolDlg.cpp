// ImageToolDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ImageTool.h"
#include "ImageToolDlg.h"
#include "AddDlg.h"
#include "ModifyDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImageToolDlg dialog

CImageToolDlg::CImageToolDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CImageToolDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CImageToolDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CImageToolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CImageToolDlg)
	DDX_Control(pDX, IDC_LIST_IMAGE, m_ctrlImage);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CImageToolDlg, CDialog)
	//{{AFX_MSG_MAP(CImageToolDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST_IMAGE, OnItemchangedListImage)
	//ON_NOTIFY(LVN_ITEMCHANGING, IDC_LIST_IMAGE, OnItemchangingListImage)
	ON_WM_ERASEBKGND()
	ON_BN_CLICKED(IDC_BTN_ADD, OnBtnAdd)
	ON_BN_CLICKED(IDC_BTN_DELETE, OnBtnDelete)
	ON_BN_CLICKED(IDC_BTN_MODIFY, OnBtnModify)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImageToolDlg message handlers

BOOL CImageToolDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	//��ʼ���ؼ�
	m_ctrlImage.SetExtendedStyle(LVS_EX_FULLROWSELECT|LVS_EX_INFOTIP|LVS_EX_GRIDLINES);
//	m_ctrlImage.SubclassHeader();
	//m_lstDevInfo.XTPGetHeaderCtrl()->SetTheme(xtpControlThemeResource);
	int nCol = 0;
	m_ctrlImage.InsertColumn(nCol,_T("���"),LVCFMT_LEFT,80);nCol++;
	m_ctrlImage.InsertColumn(nCol,_T("��Ƶ��ʾ����"),LVCFMT_LEFT,100);nCol++;
	m_ctrlImage.InsertColumn(nCol,_T("��Ƶ���"),LVCFMT_LEFT,80);nCol++;
	m_ctrlImage.InsertColumn(nCol,_T("��"),LVCFMT_LEFT,80);nCol++;
	m_ctrlImage.InsertColumn(nCol,_T("Aѡ��"),LVCFMT_LEFT,80);nCol++;
	m_ctrlImage.InsertColumn(nCol,_T("Bѡ��"),LVCFMT_LEFT,80);nCol++;
	m_ctrlImage.InsertColumn(nCol,_T("Cѡ��"),LVCFMT_LEFT,80);nCol++;
	m_ctrlImage.InsertColumn(nCol,_T("Dѡ��"),LVCFMT_LEFT,80);nCol++;
	m_ctrlImage.InsertColumn(nCol,_T("��Ƶλ��"),LVCFMT_LEFT,250);nCol++;


	Init();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CImageToolDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below

void CImageToolDlg::Init()
{

	LoadSound(m_mapSound);
	InitCtrl();





}

//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CImageToolDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CImageToolDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CImageToolDlg::ShowPng(CString sName )
{
// 	Invalidate(TRUE);
// 	UpdateWindow();
// 
// 	DWORD dwNum = MultiByteToWideChar (CP_ACP, 0, sName, -1, NULL, 0);
// 	wchar_t *pwText;
// 	pwText = new wchar_t[dwNum];
// 	if(!pwText)
// 	{
// 		delete []pwText;
// 	}
// 	MultiByteToWideChar (CP_ACP, 0, sName, -1, pwText, dwNum);
// 	CClientDC *pDC = new CClientDC(GetDlgItem(IDC_PNG));
// 	CRect rect;
// 	GetDlgItem(IDC_PNG)->GetWindowRect(&rect);


// 
// 	Graphics graphics(pDC->m_hDC); // Create a GDI+ graphics object
// 	Image image(  pwText,FALSE); // Construct an image
// 	graphics.DrawImage(&image, 0, 0, rect.Width(), rect.Height());
// 	delete pDC;
// 	if (pwText != NULL){
// 		delete []pwText;
// 	}

}
BOOL CImageToolDlg::LoadSound(SOUND_MAP &mapSound)
{
	CMarkup markup;
	bool b =markup.Load("question.xml");//question
	
	if (!b){
		return FALSE;
	}
	markup.ResetMainPos();
	markup.FindElem();
   	b = markup.IntoElem();

	for (int i = 1; i <= 12; i++)
	{
		CString sClass;
		sClass.Format("class%d",i);
		if (markup.FindElem(sClass))
		{
			markup.IntoElem();
			while(markup.FindElem("subject")){
				CString sGrade = markup.GetAttrib("ok");
				b = markup.IntoElem();
				b = markup.FindElem("title");
				CString sTitle = markup.GetData();
				b = markup.FindElem("A");
				CString sA = markup.GetData();
				b = markup.FindElem("B");
				CString sB = markup.GetData();
				b = markup.FindElem("C");
				CString sC = markup.GetData();
				b = markup.FindElem("D");
				CString sD = markup.GetData();


				SOUND_INFO *pSound = new SOUND_INFO;
				pSound->sA = sA;
				pSound->sB = sB;
				pSound->sC = sC;
				pSound->sD = sD;
				pSound->sSoundName = sTitle;
				pSound->sAnswer = sGrade;
				pSound->grade = (Sound_Grade)i;
				GetSoundPath(i,pSound->sSoundPath);
				pSound->sSoundPath += "\\" + sTitle;
				m_mapSound[i].push_back(pSound);
				markup.OutOfElem();		
			}
			markup.OutOfElem();
		}

	}
	
	
	
	return TRUE;
}

BOOL CImageToolDlg::LoadImage( IMAGE_LIST &imageList )
{
	CMarkup markup;
	bool b =markup.Load("question.xml");//question

	if (!b){
		return FALSE;
	}
	markup.ResetMainPos();
	markup.FindElem();
   	b = markup.IntoElem();
	while(markup.FindElem("subject")){
			CString sGrade = markup.GetAttrib("ok");
			b = markup.IntoElem();
			b = markup.FindElem("title");
			CString sTitle = markup.GetData();
			b = markup.FindElem("url");
			CString sUrl = markup.GetData();

			IMAGE_INFO *pImage = new IMAGE_INFO;

			if (sGrade == "A"){
				pImage->grade = GradeA;
			}
			else if (sGrade == "B"){
				pImage->grade = GradeB;
			}
			else if (sGrade == "C"){
				pImage->grade = GradeC;
			}
			else if (sGrade == "D"){
				pImage->grade = GradeD;
			}
			else{
				pImage->grade = GradeUnknown;
			}
		
			pImage->sImageName = sTitle;
			pImage->sImagePath = sUrl;

			imageList.push_back(pImage);

			markup.OutOfElem();


	}


	return TRUE;
}


void CImageToolDlg::OnItemchangedListImage(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	if(pNMListView->uChanged == LVIF_STATE)
	{
		if(pNMListView->uNewState)
		{
			int nIndex = pNMListView->iItem;
			
            //Ҫ���еĲ���
			int i = 0;
			IMAGE_LIST::iterator itr = m_lstImage.begin();
			for (; itr != m_lstImage.end(); itr ++){
				if (i == nIndex){
					break;
				}
				i ++;
			}

	
			CString sImageName = (*itr)->sImagePath;
			ShowPng(sImageName);
        }
		
    }

	*pResult = 0;
}

void CImageToolDlg::OnItemchangingListImage(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	*pResult = 0;
}

BOOL CImageToolDlg::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	return CDialog::OnEraseBkgnd(pDC);
}

void CImageToolDlg::OnBtnAdd() 
{
	// TODO: Add your control notification handler code here
	CAddDlg dlg;
	if (dlg.DoModal() == IDOK){
		IMAGE_INFO *pImage = new IMAGE_INFO;
		*pImage = dlg.m_IamgeInfo;

		SOUND_INFO *pSound = new SOUND_INFO;
		*pSound = dlg.m_SoundInfo;

		m_mapSound[dlg.m_nIndex].push_back(pSound);
		SaveXml();
		InitCtrl();
	}
	
}

// void CImageToolDlg::InitCtrl()
// {
// 	m_ctrlImage.DeleteAllItems();
// 	int nRow = 0;
// 	for (IMAGE_LIST::iterator itr = m_lstImage.begin(); itr != m_lstImage.end(); itr ++){
// 		CString sRow;
// 		sRow.Format("%d",nRow+1);
// 		m_ctrlImage.InsertItem(nRow,sRow);
// 		CString sGrade;
// 		switch((*itr)->grade){
// 		case GradeA:
// 			sGrade = "A";
// 			break;
// 		case GradeB:
// 			sGrade = "B";
// 			break;
// 		case GradeC:
// 			sGrade = "C";
// 			break;
// 		case GradeD:
// 			sGrade = "D";
// 			break;
// 		default:
// 			break;
// 		}
// 		m_ctrlImage.SetItemText(nRow,1,(*itr)->sImageName);
// 		m_ctrlImage.SetItemText(nRow,2,sGrade);
// 		m_ctrlImage.SetItemText(nRow,3,(*itr)->sImagePath);
// 		nRow ++;
// 	}
// 
// }

void CImageToolDlg::InitCtrl()
{
	m_ctrlImage.DeleteAllItems();
	int nRow = 0;
	for (SOUND_MAP::iterator itr = m_mapSound.begin(); itr != m_mapSound.end(); itr ++)
	{

		SOUND_LIST &lstSound = itr->second;
		for (SOUND_LIST::iterator itr2 = lstSound.begin(); itr2 != lstSound.end(); itr2 ++)
		{
			CString sRow;
			sRow.Format("%d",nRow+1);
			m_ctrlImage.InsertItem(nRow,sRow);
			CString sGrade;
			switch((*itr2)->grade){
			case GradeA_Easy:
				sGrade = "һ���";
				break;
			case GradeA_Normal:
				sGrade = "һ����ͨ";
				break;
			case GradeA_Hard:
				sGrade = "һ������";
				break;
			case GradeB_Easy:
				sGrade = "�����";
				break;
			case GradeB_Normal:
				sGrade = "������ͨ";
				break;
			case GradeB_Hard:
				sGrade = "��������";
				break;
			case GradeC_Easy:
				sGrade = "�����";
				break;
			case GradeC_Normal:
				sGrade = "������ͨ";
				break;
			case GradeC_Hard:
				sGrade = "��������";
				break;
			case GradeD_Easy:
				sGrade = "�����";
				break;
			case GradeD_Normal:
				sGrade = "������ͨ";
				break;
			case GradeD_Hard:
				sGrade = "��������";
				break;
			default:
				break;
			}
			m_ctrlImage.SetItemText(nRow,1,(*itr2)->sSoundName);
			m_ctrlImage.SetItemText(nRow,2,sGrade);
			m_ctrlImage.SetItemText(nRow,3,(*itr2)->sAnswer);
			m_ctrlImage.SetItemText(nRow,4,(*itr2)->sA);
			m_ctrlImage.SetItemText(nRow,5,(*itr2)->sB);
			m_ctrlImage.SetItemText(nRow,6,(*itr2)->sC);
			m_ctrlImage.SetItemText(nRow,7,(*itr2)->sD);
			m_ctrlImage.SetItemText(nRow,8,(*itr2)->sSoundPath);
			nRow++;
		}
		

	

	}


// 	for (IMAGE_LIST::iterator itr = m_lstImage.begin(); itr != m_lstImage.end(); itr ++){
// 		CString sRow;
// 		sRow.Format("%d",nRow+1);
// 		m_ctrlImage.InsertItem(nRow,sRow);
// 		CString sGrade;
// 		switch((*itr)->grade){
// 		case GradeA:
// 			sGrade = "A";
// 			break;
// 		case GradeB:
// 			sGrade = "B";
// 			break;
// 		case GradeC:
// 			sGrade = "C";
// 			break;
// 		case GradeD:
// 			sGrade = "D";
// 			break;
// 		default:
// 			break;
// 		}
// 		m_ctrlImage.SetItemText(nRow,1,(*itr)->sImageName);
// 		m_ctrlImage.SetItemText(nRow,2,sGrade);
// 		m_ctrlImage.SetItemText(nRow,3,(*itr)->sImagePath);
// 		nRow ++;
// 	}
	
}

// void CImageToolDlg::SaveXml()
// {
// 	
// 	CMarkup  xmlMark;
// 	xmlMark.SetDoc(_T("<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n"));  
// 	xmlMark.AddElem("list");
// 	xmlMark.AddAttrib("count",m_lstImage.size()); 
// 	for (IMAGE_LIST::iterator itr = m_lstImage.begin(); itr != m_lstImage.end(); itr ++){
// 		xmlMark.IntoElem();
// 		xmlMark.AddElem("subject");
// 		CString sGrade;
// 		if ((*itr)->grade == GradeA){
// 			sGrade = "A";
// 		}
// 		else if ((*itr)->grade == GradeB){
// 			sGrade = "B";
// 		}
// 		else if ((*itr)->grade == GradeC){
// 			sGrade = "C";
// 		}
// 		else if ((*itr)->grade == GradeD){
// 			sGrade = "D";
// 		}
// 		xmlMark.AddAttrib("ok", sGrade);
// 		xmlMark.AddChildElem("title", (*itr)->sImageName);
// 		xmlMark.AddChildElem("url", (*itr)->sImagePath);
// 		xmlMark.OutOfElem();
// 	}
// 	
// 	xmlMark.Save("question.xml");
// 
// }


void CImageToolDlg::SaveXml()
{
	int nCount = 0;
	nCount = GetSoundCount();
	

	CMarkup  xmlMark;
	xmlMark.SetDoc(_T("<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n"));  
	xmlMark.AddElem("list");
	xmlMark.AddAttrib("count",nCount); 

	for (SOUND_MAP::iterator itr = m_mapSound.begin(); itr != m_mapSound.end(); itr ++)
	{

		SOUND_LIST &lstSound = itr->second;
		if (lstSound.size() == 0)
		{
			continue;
		}

		
		xmlMark.IntoElem();
		CString sClass;
		sClass.Format("class%d",itr->first);
		xmlMark.AddElem(sClass);
		
		for (SOUND_LIST::iterator itr2 = lstSound.begin(); itr2 != lstSound.end(); itr2 ++)
		{
			xmlMark.IntoElem();
			xmlMark.AddElem("subject");
			xmlMark.AddAttrib("ok", (*itr2)->sAnswer);
			xmlMark.AddChildElem("title", (*itr2)->sSoundName);
			xmlMark.AddChildElem("A", (*itr2)->sA);
			xmlMark.AddChildElem("B", (*itr2)->sB);
			xmlMark.AddChildElem("C", (*itr2)->sC);
			xmlMark.AddChildElem("D", (*itr2)->sD);
			xmlMark.OutOfElem();
		}
		xmlMark.OutOfElem();
	}

	xmlMark.Save("question.xml");
	
}

void CImageToolDlg::OnBtnDelete() 
{
	int nCur = m_ctrlImage.GetNextItem(-1,LVIS_SELECTED); 
	if (nCur == -1){
		AfxMessageBox("��ѡ��Ҫɾ������");
		return ;
	}

	if (IDYES != AfxMessageBox("ȷ��Ҫɾ��ѡ������?",MB_YESNO)){
		return ;
	}

	int nIndex = 0;
	SOUND_LIST::iterator itr2;
	for (SOUND_MAP::iterator itr = m_mapSound.begin();itr != m_mapSound.end(); itr ++)
	{
		SOUND_LIST& lstSound = itr->second;
		for (itr2 = lstSound.begin(); itr2 != lstSound.end(); itr2 ++)
		{
			if (nIndex == nCur){
				break;
			}
			else{
				nIndex ++;
			}
		}
		//ɾ��
		if (itr2 != lstSound.end())
		{
			CString sSoundName = (*itr2)->sSoundPath;
			DeleteFile(sSoundName);
			delete *itr2;
        	*itr2 = NULL;
			lstSound.erase(itr2);
			break;
		}
	}

	SaveXml();
	InitCtrl();
}

void CImageToolDlg::OnBtnModify() 
{
	// TODO: Add your control notification handler code here
	int nCur = m_ctrlImage.GetNextItem(-1,LVIS_SELECTED); 
	if (nCur == -1){
		AfxMessageBox("��ѡ��Ҫ�޸ĵ���");
		return ;
	}
	
	
	SOUND_LIST::iterator itr2;
	SOUND_INFO *pSoundInfo = NULL;
	int nIndex = 0;
	for (SOUND_MAP::iterator itr = m_mapSound.begin();itr != m_mapSound.end(); itr ++)
	{
		SOUND_LIST& lstSound = itr->second;
		for (itr2 = lstSound.begin(); itr2 != lstSound.end(); itr2 ++)
		{
			if (nIndex == nCur){
				break;
			}
			else{
				nIndex ++;
			}
		}
		
		if (itr2 != lstSound.end())
		{
			pSoundInfo = *itr2;
			break;
		}
	}

	CModifyDlg dlg(pSoundInfo);
	if (dlg.DoModal() == IDOK)
	{
		SaveXml();
		InitCtrl();
	}
}

void CImageToolDlg::GetSoundPath( int index,CString &sPath )
{
	switch(index)
	{
	case 1:
		sPath = ".\\config\\mp3\\1\\easy";
		break;
	case 2:
		sPath = ".\\config\\mp3\\1\\middle";
		break;
	case 3:
		sPath = ".\\config\\mp3\\1\\hard";
		break;
	case 4:
		sPath = ".\\config\\mp3\\2\\easy";
			break;
	case 5:
		sPath = ".\\config\\mp3\\2\\middle";
			break;
	case 6:
		sPath = ".\\config\\mp3\\2\\hard";
		break;
	case 7:
		sPath = ".\\config\\mp3\\3\\easy";
			break;
	case 8:
		sPath = ".\\config\\mp3\\3\\middle";
			break;
	case 9:
		sPath = ".\\config\\mp3\\3\\hard";
		break;
	case 10:
		sPath = ".\\config\\mp3\\4\\easy";
			break;
	case 11:
		sPath = ".\\config\\mp3\\4\\middle";
			break;
	case 12:
		sPath = ".\\config\\mp3\\4\\hard";
		break;
	default:
		break;
	}

}

int CImageToolDlg::GetSoundCount()
{
	int nCount = 0;
	for (SOUND_MAP::iterator itr = m_mapSound.begin(); itr != m_mapSound.end(); itr ++)
	{
		SOUND_LIST &lstSound = itr->second;
		nCount += lstSound.size();
	}
	return nCount;
}
